package com.reel2real.backend.repository;

import com.reel2real.backend.entity.ItineraryVersion;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface ItineraryVersionRepository extends JpaRepository<ItineraryVersion, UUID> {

    // 🔒 PHASE-3 PATCH START
    @Modifying
    @Transactional
    @Query("update ItineraryVersion v set v.active = false where v.tripId = :tripId")
    void deactivateByTripId(UUID tripId);

    @Query("select max(v.versionNumber) from ItineraryVersion v where v.tripId = :tripId")
    Optional<Integer> findMaxVersion(UUID tripId);
    // 🔒 PHASE-3 PATCH END
}
