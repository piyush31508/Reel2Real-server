package com.reel2real.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reel2realBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(Reel2realBackendApplication.class, args);
	}

}
