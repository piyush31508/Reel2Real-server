package com.reel2real.backend.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "places")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Place {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(nullable = false, length = 150)
    private String name;

    @Column(nullable = false, length = 100)
    private String city;

    @Column
    private String country;

    @Column(length = 50)
    private String category;

    private Double latitude;
    private Double longitude;

    @Column(name = "google_maps_url")
    private String googleMapsUrl;

    private String activity;
    private String season;
    private String crowdLevel;
    private String budgetLevel;
    private String safetyNote;
    private Integer minCost;
    private Integer maxCost;
    @Column(name = "enrichment_status")
    private String enrichmentStatus;
    private LocalDateTime lastEnrichedAt;

}
