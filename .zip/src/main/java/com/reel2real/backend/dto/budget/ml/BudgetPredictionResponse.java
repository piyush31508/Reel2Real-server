// BudgetPredictionResponse.java
package com.reel2real.backend.dto.budget.ml;

import lombok.Data;

@Data
public class BudgetPredictionResponse {
    private double estimatedCost;
}
