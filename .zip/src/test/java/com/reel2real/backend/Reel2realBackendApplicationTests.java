package com.reel2real.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reel2realBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
